#include <stdio.h>
#define PR(format, value) printf(#value " = " format "\t", value)
#define NL putchar('\n')
#define PRINT1(f, x1) PR(f, x1), NL
#define PRINT2(f, x1, x2) PR(f, x1), PRINT1(f, x2)
#define PRINT3(f, x1, x2, x3) PR(f, x1), PRINT2(f, x2, x3)
#define PRINT4(f, x1, x2, x3, x4) PR(f, x1), PRINT3(f, x2, x3, x4)
void main()
{
    static struct S1 {
        char c[4], *s;
    } s1 = { "abc", "def" };
    static struct S2 {
        char *cp;
        struct S1 ss1;
    } s2 = { "ghi", { "jkl", "mno" } };
    PRINT2("%c", s1.c[0], *s1.s);
    PRINT2("%s", s1.c, s1.s);
    PRINT2("%s", s2.cp, s2.ss1.s);
    PRINT2("%s", ++s2.cp, ++s2.ss1.s);
}