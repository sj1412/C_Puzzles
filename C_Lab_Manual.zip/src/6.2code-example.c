#include <stdio.h>
#define PR(format, value) printf(#value " = " format "\t", value)
#define NL putchar('\n')
#define PRINT1(f, x1) PR(f, x1), NL
#define PRINT2(f, x1, x2) PR(f, x1), PRINT1(f, x2)
#define PRINT3(f, x1, x2, x3) PR(f, x1), PRINT2(f, x2, x3)
#define LOW 0
#define HIGH 5
#define CHANGE 2

int i = LOW;  
int reset(int i);         
int workover(int i);      
void main() {
    auto int i = HIGH;  
    reset(i / 2);           PRINT1("%d", i);  
    reset(i = i / 2);       PRINT1("%d", i);  
    i = reset(i / 2);       PRINT1("%d", i);  
    workover(i);            PRINT1("%d", i);  
}
int reset(int i) {
    i = i <= CHANGE ? HIGH : LOW;
    return i;
}
int workover(int i) {
    int result = 0;
    result = (i % i) * ((i * i) / (2 * i) + 4);
    PRINT1("%d", result);
    return result;
}