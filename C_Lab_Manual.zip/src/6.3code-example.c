#include <stdio.h>
#define PR(format, value) printf(#value " = " format "\t", value)
#define NL putchar('\n')
#define PRINT1(f, x1) PR(f, x1), NL
#define PRINT2(f, x1, x2) PR(f, x1), PRINT1(f, x2)
#define PRINT3(f, x1, x2, x3) PR(f, x1), PRINT2(f, x2, x3)
#define PRINT4(f, x1, x2, x3, x4) PR(f, x1), PRINT3(f, x2, x3, x4)

int i = 1;
int reset(void);
int next(int j);
int last(int j);
int new(int i);

int main()
{
    auto int i, j;
    i = reset();
    for (j = 1; j <= 3; j++) {
        PRINT2("%d", i, j);
        PRINT1("%d", next(i));
        PRINT1("%d", last(i));
        PRINT1("%d", new(i + j));
    }
    return 0;
}
int reset(void)
{
    return 1;
}
int next(int j)
{
    return (j = i++); 
}
int last(int j)
{
    static int i = 10;
    return (j = i--);
}
int new(int i)
{
    auto int j = 10;
    return (i =j+=i);
}