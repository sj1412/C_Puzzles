#include<stdio.h>
void main ( ){
int x=2, y, Z;
x *= 3 + 2;  printf("%d",x);
x *= y = Z = 4; printf("%d",x);
x = y == Z; printf("%d",x);
x == ( y = Z ); printf("%d",x);

}
