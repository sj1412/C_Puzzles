#include <stdio.h>
#define PR(format, value) printf(#value " = " format "\t", value)
#define NL putchar('\n')
#define PRINT1(f, x1) PR(f, x1), NL
#define PRINT2(f, x1, x2) PR(f, x1), PRINT1(f, x2)
#define PRINT3(f, x1, x2, x3) PR(f, x1), PRINT2(f, x2, x3)
#define PRINT4(f, x1, x2, x3, x4) PR(f, x1), PRINT3(f, x2, x3, x4)
void main() {
    int x, y = 1, z;
    if (y != 0) x = 5;
    PRINT1("%d", x);
    if (y == 0) x = 3;
    else x = 5;
    PRINT1("%d", x);
    x = 1;
    if (y < 0) if (y > 0) x = 3;
        else x = 5;
    PRINT1("%d", x);
    if (z = y < 0) x = 3;
    else if (y == 0) x = 5;
    else x = 7;
    PRINT2("%d", x, z);
    if (z = (y == 0)) x = 5;
    x = 3;
    PRINT2("%d", x, z);
    if (x = z = y);
    x = 3;
    PRINT2("%d", x, z);
}