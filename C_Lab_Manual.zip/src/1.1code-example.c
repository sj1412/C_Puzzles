#include<stdio.h>
void main () {
int x;
x= -3 + 4 * 5 -6; printf("%d",x);
x=   3 + 4 % 5 - 6; printf("%d",x);
x= -3 * 4 % - 6 / 5; printf("%d",x);
x=  (7 + 6) % 5 / 2; printf("%d",x);
}
